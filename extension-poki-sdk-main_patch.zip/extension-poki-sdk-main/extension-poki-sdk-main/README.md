# Poki SDK Extension for Defold

Defold [native extension](https://www.defold.com/manuals/extensions/) which provides access to the Poki SDK.

[Manual, API and setup instructions](https://www.defold.com/extension-poki-sdk/) is available on the official Defold site.
